/** Automatically generated file. DO NOT MODIFY */
package edu.birzeit.fall2014.encs539.id1110600.AdventureGame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}